import csv
import codecs
def monstres_csv():
    monstres_list = []
    with codecs.open('ennemies_liste.csv','r') as csvfile:
        r=csv.DictReader(csvfile,delimiter=';')
        for row in r:
            monstres_list.append(dict(row))
    return monstres_list

def recompense():
    objets_list_T = []
    with codecs.open('liste_objets.csv','r') as csvfile:
        r=csv.DictReader(csvfile,delimiter=',')
        for row in r:
            objets_list_T.append(dict(row))
    return objets_list_T

def joueur_stats(statistiques):
    """
    Cette fonction retourne les statistiques du joueur, sa vie, sa défense et sa chance, servant à calculer la vie qu'il perd ou la puissance des attaque qui va                   infliger.

    Pré-Condition : Stats est un tableau composé de 3 éléments, non vide.

    Post-condition : Est retourné Stats, tableau non vide composé de 3 éléments.
    """
    return statistiques
    #vie,defense,chance,argent,defense


def combat_tours(ennemi,stat,vie_ennemi,inv):
    """
    Cette fonction est appelée à chaque tour. Elle demmande à chaque fois ce que le joueur choisit de faire. 

    Pré-condition : 
    vie_joueur est un nombre entre 0 et 100. C'est les points de vie du joueur. Ces points de vies sont ensuite envoyés à la fonction attaque() si choisie.
    stat est les statistiques du joueur, contenant la vie, l'attaque, la defense, la chance et l'argent.
    vie_ennemi est la vie de l'ennemi.

    Post-condition : Si les conditions de "continuation" sont bonnes, une des quatres fonction est appelée (attaque, fuir, se cacher ou inventaire)
    """
    if (vie_ennemi > 0) and (stat['vie'] > 0):
        monstres = monstres_csv()
        print("x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x")
        print("Ennemi :")
        print(str(monstres[ennemi]["nom"]))
        print("x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x")
        print("Que Faire ?")
        print("1. ATTAQUER")
        print("2. FUIR")
        print("3. SE CACHER")
        print("4. INVENTAIRE")
        print("x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x")
        choix_histoire = int(input("Faites un choix ! -> "))
        if choix_histoire == 1:
            attaque(ennemi,stat,vie_ennemi,inv)
        elif choix_histoire == 2:
            fuir(ennemi,stat,vie_ennemi,inv)
        elif choix_histoire == 3:
            cache(ennemi,stat,vie_ennemi,inv)
        elif choix_histoire == 4:
            inventaire(ennemi,stat,vie_ennemi,inv)
        else:
            print("Il est impossible de faire cela.")
            combat_tours(ennemi,stat,vie_ennemi,inv)
    else:
        print("x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x")
        print("Combat terminé, l'ennemi est vaincu.")
        print("x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x")
        print("Vous obtenez", int(monstres[ennemi]['rec']), "pièces")
        return int(monstres[ennemi]['rec'])

def fuir(ennemi,stat,vie_ennemi,inv):       
    """
    Cette fonction sert à fuir, c'est-à-dire échapper le combat. Cela dépend du monstre choisit.
    """
    monstres = monstres_csv()
    if (monstres[ennemi]["fuit"] == "possible"):
        print("Vous avez fuit avec succès!")
        return stat
    else:
        print("Vous avez essayé de fuir, mais votre ennemi vous a ratrappé, la fuite n'est pas possible!")
        combat_tours(ennemi,stat,vie_ennemi,inv)
        return 1

def cache(ennemi,stat,vie_ennemi,inv): 
    monstres = monstres_csv()
    if monstres[ennemi]["cac"] == "possible":
        print("Vous vous êtes caché, votre ennemi vous a pas vu!")
        return stat
    else:
        print("Vous vous êtes caché, mais votre ennemi vous a retrouvé, se cacher est impossible!")
        combat_tours(ennemi,stat,vie_ennemi,inv)       
        return 1


def attaque(ennemi,stat,vie_ennemi,inv):
    """
    Cette fonction calcule les points d'attaque que le joueur va infliger à l'ennemi au tour "ATTAQUER".
    """
    monstres = monstres_csv()
    vie_joueur = stat['vie']
    if vie_joueur > 0 and vie_ennemi > 0:
        #importation_statistiques
        #points_attaque_base
        point_attaque = stat['attaque']
        #attaque_supplementaire_objets
        att_sup = 2
        #variablechance
        chance = stat['chance']
        #calcul_points_attaque
        att_final = point_attaque + att_sup + chance/7
        print("Attaque effectuée avec succès!")
        #continuation
        vie_ennemi = vie_ennemi - att_final
        if vie_ennemi < 0:
            print("x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x")
            print("Combat terminé, l'ennemi est vaincu.")
            print("x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x")
            print("Vous obtenez", int(monstres[ennemi]['rec']), "pièces")
            stat['argent'] = stat['argent'] + int(monstres[ennemi]['rec'])
            print("Vous avez maintenant", stat['argent'], "pièces.")
            return stat
        else:
            monstre_attaque(ennemi,stat,vie_ennemi,inv)
            return vie_ennemi
    else:
        return stat

def monstre_attaque(ennemi,stat,vie_ennemi,inv):
    """
    Cette fonction inflige les dégats aux joueurs par l'ennemi
    """
    monstres = monstres_csv()
    vie_joueur = stat['vie']
    #importation_liste_csv
    ennemi_nom = monstres[ennemi]["nom"]
    #importation_monstre_selectionner
    defense_joueur = stat['defense']
    chance_joueur = stat['chance']
    print("x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x")
    print(ennemi_nom, "vous attaque !")
    #effet_du_monstre
    attaque_ennemi_supp = 1
    #calcul_vie_joueur_restante
    attaque_ennemi = int(monstres[ennemi]["att"])
    point_attaque_ennemi = ((attaque_ennemi + attaque_ennemi_supp)-(chance_joueur/15 + defense_joueur / 5))
    vie_joueur = round(vie_joueur - point_attaque_ennemi,1)
    print("Vous perdez", round(point_attaque_ennemi,1), "points de vie")
    print("Vous avez maintenant", vie_joueur, "points de vie")
    stat['vie']=vie_joueur
    if vie_joueur <= 0:
        print("x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x")
        print("Combat terminé, l'ennemi vous a vaincu.")
        print("x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x")
        argent_perdue = randint(1,10)
        print("Vous perdez", argent_perdue, "pièces")
        stat['argent'] = stat['argent']-argent_perdue
        return stat
    else:
        combat_tours(ennemi,stat,vie_ennemi,inv)
        return stat


def inventaire(ennemi,stat,vie_ennemi,inv):
    print("x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x")
    print("Voici votre inventaire:")
    print(inv)
    print("x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x")
    combat_tours(ennemi,stat,vie_ennemi,inv)

from random import randint
from random import shuffle
def apparition(zone):
    """
    Cette fonction permet de selectionner le monstre adéquat à la zone / progression du joueur tout en prenant compte de sa raretée

    Pré-conditions : L'indice des monstres de la zone adéquate est cherchée.

    Post-condition : Est retourné le monstre selectionné, plus précisemment son indice.
    """
    stat = joueur_stats
    monstres = monstres_csv()
    Z1=[e['indice'] for e in monstres if (int(e['zon1'])) == (zone)]
    Z2=[e['indice'] for e in monstres if (int(e['zon2'])) == (zone)]
    Z3=[e['indice'] for e in monstres if (int(e['zon3'])) == (zone)]
    zone_liste = Z1 + Z2 + Z3 #zone est l'ensemble de Z1, Z2 et Z3.
    shuffle(zone_liste) #zone est trié aléatoirement 
    for e in range(len(zone_liste)-1):
        if int(monstres[int(zone_liste[e])]["rar"]) > randint(0,100):
            choix = int(zone_liste[e])
            return choix

def combat_main(zone,statistiques_joueur,inv):
    """
    C'est la fonction principale du fichier, elle annonce l'arrivée du monstre choisit à la fonction apparition() et d'établir le premier choix du joueur.
    S'il veut attaquer l'ennemi, la fonction attaque() est appellée, s'il veut fuir, la fonction fuir() est appellée, s'il veut sa cacher, la fonction
    cache() est appellée et enfin, s'il veut voir dans son inventaire / interagir avec, inventaire() est appellée.
    On pourrait dire que cette fonction est la présentation du combat.
    """
    monstres = monstres_csv()
    ennemi = apparition(zone)
    print("x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x")
    arrivee= (monstres[ennemi]["arr"])
    print(arrivee)
    print("Que Faire ?")
    print("1. ATTAQUER")
    print("2. FUIR")
    print("3. SE CACHER")
    print("4. INVENTAIRE")
    print("x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x")
    vie_ennemi = int(monstres[ennemi]['vie'])
    attaque_ennemi = int(monstres[ennemi]['att'])
    vie_joueur = statistiques_joueur['vie']
    attaque_joueur = statistiques_joueur['attaque'] 
    chance_joueur = statistiques_joueur['chance'] 
    defense_joueur = statistiques_joueur['defense'] 
    argent_joueur = statistiques_joueur['argent']
    input_done = False
    while input_done == False:
        choix_histoire = int(input("Faites un choix ! -> "))
        if choix_histoire == 1:
            input_done = True
            attaque(ennemi,statistiques_joueur,vie_ennemi,inv)
        elif choix_histoire == 2:
            input_done = True
            fuir(ennemi,statistiques_joueur,vie_ennemi,inv)
        elif choix_histoire == 3:
            input_done = True
            cache(ennemi,statistiques_joueur,vie_ennemi,inv)
        elif choix_histoire == 4:
            input_done = True
            inventaire(ennemi,statistiques_joueur,vie_ennemi,inv)

