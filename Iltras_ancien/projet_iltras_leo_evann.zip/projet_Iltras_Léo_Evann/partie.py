from random import randint
from random import shuffle
from combat_fonctions import monstres_csv
from combat_fonctions import combat_main
from combat_fonctions import combat_tours
import csv
import codecs


def obj():
    T_obj_1=[]
    with codecs.open('liste_objets.csv','r') as csvfile:
        r=csv.DictReader(csvfile,delimiter=',')
        for row in r:
            T_obj_1.append(dict(row))
        return T_obj_1


#un coffre apparait...
def chest():
    objets = obj()
    zone_minimum = 1
    coffre_loot= [e['ind'] for e in objets if int(e['cof']) == 1]
    objet = 0
    while objet != 1:
        shuffle(coffre_loot)
        for e in range(len(coffre_loot)-1):             
            if (int(objets[int(coffre_loot[e])]['ctl']) > randint(0,100)) and (int(objets[int(coffre_loot[e])]['zon_min']) <= zone_minimum):
                return coffre_loot[e]


def mise_en_context(stat):
    """
    Cette fonction sert à importer les statistiques des classes de base. Puisque les statistiques sont sujets à changement, il faut déjà importer les stats de base.
    """
    partie_deroulement(stat)
    return stat

def partie_deroulement(stat):
    """
    Cette fonction détermine ce qui est à faire. Soit : un coffre est ouvert, Soit : un combat s'active, Soit : Rien ne se passe et l'histoire continue. 
    """
    liste_monstres = monstres_csv()
    objets = obj()
    vie_ennemi = 10
    aleatoire = randint(0,3)
    if (aleatoire) >= 0 and (aleatoire) < 1: #il y a 33% de chance d'activer un combat
        combat_main(stat)
    elif (aleatoire) >= 1 and (aleatoire) < 2:   #Il y a 33% de chance d'ouvrir un coffre.
        objet = int(chest())
        print("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=")
        print("En marchant un peu, vous avez trouvé un coffre...")
        print("L'ouvrir?")
        choix = 0
        while (choix != 1) or (choix != 2):
            choix = int(input("|     1-Oui , 2-Non   | => "))
            print("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=")
            if choix == 1:
                if randint(0,2) > 1.75:            #Si le coffre est ouvert, il y a 17.5% de chance de se retrouver avec un faux coffre. (donc un ennemi.)
                    combat_tours(23,stat['vie'],liste_monstres[23]['vie'])
                elif randint(0,2) < 1.75:        #Si le coffre est ouvert, il y a 82.5% de chance de récupérer un objet
                    print("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=")
                    print("Vous remportez", objets[objet]["nom"])
                    print("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=")
                    partie_deroulement(stat)
            elif choix == 2:
                    print("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=")
                    print("Vous auriez pu remporter", objets[objet]["nom"],"...dommage!")
                    print("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=")
                    partie_deroulement()
            elif (aleatoire) >= 2 and (aleatoire) < 3:
                return "histoire"