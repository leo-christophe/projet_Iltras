from random import randint
from random import choice
import csv
import codecs
from boutique import boutique_debut
from evenements import chest
from combat_fonctions import combat_tours
from combat_fonctions import combat_main
from partie import partie_deroulement

def scen():
    T_hist_1=[]
    with codecs.open('scenario.csv','r') as csvfile:
        r=csv.DictReader(csvfile,delimiter=',')
        for row in r:
            T_hist_1.append(dict(row))
        return T_hist_1
def obj():
    T_obj_1=[]
    with codecs.open('liste_objets.csv','r') as csvfile:
        r=csv.DictReader(csvfile,delimiter=',')
        for row in r:
            T_obj_1.append(dict(row))
        return T_obj_1


def histoire_principale_d(stat):
    '''Ce programme est le programme principal du jeux c'est là que l'histoire est développée.'''
    hist = scen()
    zone=0
    print("------------------------------------------------")
    print(hist[1]['scen1'])
    print(hist[1]['scen2'])
    print("------------------------------------------------")
    print(hist[1]['scen3'])
    inventaire = {}
    if 'Petit couteaux' in inventaire:
        inventaire['Petit couteaux']=inventaire['Petit couteaux']+1
    else:
        inventaire['Petit couteaux']=1
    if 'Côte de boeuf' in inventaire:
        inventaire['Côte de boeuf']=inventaire['Côte de boeuf']+1
    else:
        inventaire['Côte de boeuf']=1
    print("------------------------------------------------")
    print(inventaire)
    print("------------------------------------------------")
    print(hist[1]['scen4'])
    print("------------------------------------------------")
    choix_1 = 0
    while (choix_1!=1) and (choix_1!=2):
         choix_1= int(input("1-Vous partez à gauche vers le centre ville 2-Vous prenez à droite direction la grotte."))
    if choix_1==2:
        print("------------------------------------------------")
        print(hist[1]['scen7'])
        print(hist[1]['scen8'])
        print(hist[1]['scen9'])
        print(hist[1]['scen10'])
        print(hist[1]['scen11'])
        print("------------------------------------------------")
        combat_tours(107,stat,90)
        print("Vous auriez du écouter les interdictions de vos parents.")
        print("GAME OVER.")
    elif choix_1==1:
        print("------------------------------------------------")
        print(hist[1]['scen12'])
        print("------------------------------------------------")
        choix_2= int(input("1-Vous décidez d'aller faire des achats dans une boutique ; 2-Vous partez sans aucuns remords en direction de la sortie du village."))
        while int(choix_2!=1) and int(choix_2!=2):
            choix_2= int(input("1-Vous décidez d'aller faire des achats dans une boutique ; 2-Vous partez sans aucuns remords en direction de la sortie du village."))
        if choix_2==1:
            print("------------------------------------------------")
            print("Vous vous dirigé vers une grande boutiques dont l'enseigne ne tient en place que par la volonté de dieux.'")
            print("Vous y entrez d'un pas déterminé !'")
            print("------------------------------------------------")
            boutique_debut(0,stat,inventaire)
        elif choix_2==2:
            print("Vous pensez que ce n'est qu'une perte de temps, donc, vous sortez directement du village.")
        print("Vous arrivez à la sortie du village, 3 chemins s'offrent à vous.")
        print("------------------------------------------------")
        choix_chemin_1 = 0
        while int(choix_chemin_1!= 1) and int(choix_chemin_1!=2) and int(choix_chemin_1!=3):
            choix_chemin_1= int(input("Vous décidez de partir en direction: 1-De la foret ; 2-Des plaines ; 3-Des montagnes."))
        if choix_chemin_1==1: #début de la forêt
            foret(inventaire,stat)
        elif choix_chemin_1==2: #début plaine
            plaine(inventaire,stat)
        elif choix_chemin_1==3:
            montagne(inventaire,stat)

def foret(inv,stat):
    hist = scen()
    zone=111
    print("------------------------------------------------")
    print(hist[2]['scen1'])
    print(hist[2]['scen2'])
    combat_main(zone,stat,inv)
    print(hist[2]['scen3'])
    print(hist[2]['scen4'])
    combat_main(zone,stat,inv)
    print(hist[2]['scen5'])
    print("------------------------------------------------")
    choix_chemin_2 = 0
    while int(choix_chemin_2!=1) and int(choix_chemin_2!=2):
        choix_chemin_2=int(input("Vous prenez 1- à droite 2- à gauche"))
    if choix_chemin_2==1:
        print("------------------------------------------------")
        print(hist[2]['scen6'])
        print("------------------------------------------------")
        stat['vie']=stat['vie']-5
        if stat['vie'] <= 0:
            print("game over! vous avez perdu.")
            return "vous avez perdu."
    elif choix_chemin_2==2:
        print("------------------------------------------------")
        print(hist[2]['scen7'])
        combat_main(zone,stat,inv)
        print(hist[2]['scen8'])
        combat_main(zone,stat,inv)
        print(hist[2]['scen9'])
        print("------------------------------------------------")
        choix_coffre_1 = 0
        while int(choix_coffre_1!=1) and int(choix_coffre_1!=2):
            choix_coffre_1=int(input("Que choisissez vous de faire ? 1- Fouiller la maisonnette 2- Continuer votre chemin ."))
        if choix_coffre_1==1:
            print("------------------------------------------------")
            print(hist[2]['scen10'])
            print("------------------------------------------------")
            print("Vous obtenez...")
            objets = obj()
            loot = int(chest())
            print(objets[loot]["nom"])
            if objets[loot]["nom"] in inv:
                inv[objets[loot]["nom"]] = inv[objets[loot]["nom"]]+1
            else:
                inv[objets[loot]["nom"]] = 1
            print("votre inventaire:")
            print(inv)
        elif choix_coffre_1==2:
            print("------------------------------------------------")
            print(hist[2]['scen11'])
            print("------------------------------------------------")
    print(hist[2]['scen12'])
    print(hist[2]['scen13'])
    print("Vous obtenez...")
    objets = obj()
    loot = int(chest())
    print(objets[loot]["nom"])
    if objets[loot]["nom"] in inv:
        inv[objets[loot]["nom"]] = inv[objets[loot]["nom"]]+1
    else:
        inv[objets[loot]["nom"]] = 1
    print("votre inventaire:")
    print(inv)
    print("------------------------------------------------")
    print(hist[2]['scen14'])
    print(hist[2]['scen15'])
    print("------------------------------------------------")
    #fin forêt
    foret_continue(inv,stat)
def plaine(inv,stat):
    hist=scen()
    zone=112
    print("------------------------------------------------")
    print(hist[3]['scen1'])
    print(hist[3]['scen2'])
    print(hist[3]['scen3'])
    print("------------------------------------------------")
    choix_chemin_3=int(input("1-Vous décidez de vous y rendre ; 2-Vous continuez votre chemin."))
    while (choix_chemin_3!=1) and (choix_chemin_3!=2):
        choix_chemin_3=int(input("1-Vous décidez de vous y rendre ; 2-Vous continuez votre chemin."))
        if choix_chemin_3==1:
            print("------------------------------------------------")
            print(hist[3]['scen4'])
            combat_tours(9,stat,8)
        elif choix_chemin_3==2:
            print("------------------------------------------------")
            print(hist[3]['scen5'])
            print("------------------------------------------------")
            print(hist[3]['scen6'])
            print(hist[3]['scen7'])
            print("------------------------------------------------")
            #fin plaine
    plaine_continue(inv,stat)

def montagne(inv,stat):
    hist = scen()
    zone=113
    print("------------------------------------------------")
    print(hist[4]['scen1'])
    print(hist[4]['scen2'])
    #perdre 3 point de vie
    print(hist[4]['scen3'])
    #perdre 3 point de vie
    print("------------------------------------------------")
    choix_chemin_4 = 0
    while (choix_chemin_4!=1) and (choix_chemin_4!=2):
        choix_chemin_4=int(input("1- Vous vous arrêter pour vous reposer. 2- Vous continuez."))
    if choix_chemin_4==1:
        print("------------------------------------------------")
        print(hist[4]['scen4'])
        stat['vie'] = stat['vie'] + 10
        if stat['vie'] > 100:
            stat['vie'] = 100
        print("------------------------------------------------")
    elif choix_chemin_4==2:
        print("------------------------------------------------")
        print(hist[4]['scen5'])
        stat['vie'] = stat['vie']-3
    print("------------------------------------------------")
    print(hist[4]['scen6'])
    print("------------------------------------------------")
    stat = combat_main(zone,stat,inv)
    choix_chemin_5 = 0
    while choix_chemin_5!=1 and choix_chemin_5!=2:
        choix_chemin_5=int(input("1-Vous décidez de grimper au sommet 2- Vous décidez de prendre le côté."))
    if choix_chemin_5==1:
        print("------------------------------------------------")
        print(hist[4]['scen7'])
    elif choix_chemin_5==2:
        print("------------------------------------------------")
        print(hist[4]['scen8'])
    print("------------------------------------------------")
    print(hist[4]['scen9'])
    print("Vous obtenez...")
    objets = obj()
    for i in range(0,3):
        loot = int(chest())
        print(objets[loot]["nom"])
        if objets[loot]["nom"] in inv:
            inv[objets[loot]["nom"]] = inv[objets[loot]["nom"]]+1
        else:
            inv[objets[loot]["nom"]] = 1
    print("votre inventaire:")
    print(inv)
    print(hist[4]['scen10'])
    print("------------------------------------------------")
    montagne_continue(inv,stat)

def foret_continue(inv,stat):
    print("Finalement, vous êtes démotivé, vous rentrez chez vous et vous pensez repartir quand la motivation sera revenue.")
    fin(inv,stat)
def montagne_continue(inv,stat):
    print("Finalement, vous êtes démotivé, vous rentrez chez vous et vous pensez repartir quand la motivation sera revenue.")
    fin(inv,stat)
def plaine_continue(inv,stat):
    print("Finalement, vous êtes démotivé, vous rentrez chez vous et vous pensez repartir quand la motivation sera revenue.")
    fin(inv,stat)
def fin(inv,stat):
    print("Aussi, par soucis de budget, et de temps, vous décidez de retourner dans votre village pour plus longtemps que prévu. Vous vous achetez une petite maison au bord d'une rivière et devenez alcoolique.")
    print("Votre inventaire :",inv)
    print("Vos statistiques :", stat)
    print("Merci d'avoir joué à la démo d'Iltras. Nous n'avions pas eu le temps de développer l'histoire comme nous le voulions, donc peut-être qu'il y aura une suite plus tard, peut être pas...")
    print("Léo et Evann")