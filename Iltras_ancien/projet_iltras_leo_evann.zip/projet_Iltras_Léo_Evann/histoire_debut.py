from random import choice
from random import randint
import csv
import codecs
from histoire_principale import histoire_principale_d

def obj():
    T_obj_1=[]
    with codecs.open('liste_objets.csv','r') as csvfile:
        r=csv.DictReader(csvfile,delimiter=',')
        for row in r:
            T_obj_1.append(dict(row))
        return T_obj_1

def debut():
    """Ce programme sert à choisir sa classe de personnage.
    préconditions: le joueur doit choisir une classe avec un numéro allant de 1 à 3.
    postconditions: le programme renvoit un numéro associer à une classe (1,2 ou 3)
    """
    choix_joueur=int(input("Quel personnage rêve tu de devenir ? 1-Chevalier; 2-Clypeus; 3-Lutin."))
    while (choix_joueur!=1) and (choix_joueur!=2) and (choix_joueur!=3):
        choix_joueur=input("choisit un personnage entre 1-Chevalier , 2-Clypeus , 3-Lutin.")
    return choix_joueur

def choix_nom():
    '''Ce programme permet au joueur de choisir son nom d'aventurier/aventurière.'''
    choix_nom_joueur=input("Quel est ton nom, aventurier/ aventurière ?")
    print(choix_nom_joueur,"? Quel beau nom. Enchanté!")
    return choix_nom_joueur

def classe_choix():
    """
    Ce programme est le programme principal du jeux c'est là que l'histoire est développée.
    """
    objets=obj()
    inv={}
    stat={}
    print("------------------------------------------------")
    print("Bonjour, à toi aventurier bienvenue dans le monde d'Iltras !'")
    print("------------------------------------------------")
    nom=choix_nom()
    print("Maintenant,",nom,", tu dois choisir une classe.")
    print("------------------------------------------------")
    c_c = debut()
    if c_c == 1:
        print("Par la bénédiction de la sainte frite, te voila Chevalier !!!")
        stat={"vie":100,"attaque":10,"defense":5,"chance":5,"argent":200}
        print("Voici tes statistiques :")
        print(stat)
    if c_c == 2:
        print("Mais que voila est-ce un mur,non ça m'a l'air plus dur, voici donc le fameux Clypeus !!")
        stat={"vie":100,"attaque":3,"defense":20,"chance":7,"argent":100}
        print("Voici tes statistiques :")
        print(stat)
    if c_c == 3:
        print("Saperlipopette ! Par la magie des bottes de Merlin ! Enchanté! This is THE Lutin !!")
        stat={"vie":100,"attaque":1,"defense":3,"chance":75,"argent":1000}
        print("Voici tes statistiques :")
        print(stat)
    print("------------------------------------------------")
    continuer = 0
    while continuer != 1:
        continuer=int(input("Pour continuer, tapez 1."))
    histoire_principale_d(stat)
classe_choix()
