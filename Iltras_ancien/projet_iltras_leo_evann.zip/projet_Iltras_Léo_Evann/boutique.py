import csv
import codecs

def obj():
    T_obj_1=[]
    with codecs.open('liste_objets.csv','r') as csvfile:
        r=csv.DictReader(csvfile,delimiter=',')
        for row in r:
            T_obj_1.append(dict(row))
        return T_obj_1

def boutique_main():
    objets = obj()
    achetable_0=[int(e['ind']) for e in objets if (int(e['Bouti-achet']) == 0)]
    return achetable_0

def boutique_capit():
    objets = obj()
    achetable_1=[e['ind'] for e in objets if (int(e['Bouti-achet']) == 1)]
    return achetable_1

def boutique_port():
    objets = obj()
    achetable_2=[e['ind'] for e in objets if (int(e['Bouti-achet']) == 2)]
    return achetable_2

def boutique_jungle():
    objets = obj()
    achetable_3=[e['ind'] for e in objets if (int(e['Bouti-achet']) == 3)]
    return achetable_3

def boutique_volcan():
    objets = obj()
    achetable_4=[e['ind'] for e in objets if (int(e['Bouti-achet']) == 4)]
    return achetable_4

def vente(stat,inventaire):
    print("Je ne vends rien! T'as cru que c'était une brocante ?")
    boutique_debut(stat,inventaire)
    """objets = obj()
    print("Inventaire:")
    for e in range(len(inventaire)-1):
        print(inventaire)"""
    """print("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*")
    choix_vente = 0
    while (choix_vente != (1,len(inventaire)+1)) and (choix_vente != -1):
        choix_vente = int(input("Que voulez vous vendre? (Entrez le numéro correspondant),-1 pour revenir en arrière"))
        print("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*")
        valeur = [e['indice'] for e in objets if e["nom"] == inventaire[choix_vente]]
        print("Vous avez vendu :",choix_vente)
        print("Pour", valeur)
        print("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*")
    boutique_debut(stat,inventaire)"""

def boutique_debut(boutique,stat,inventaire):
    objets = obj()
    if boutique == 0:
        achetable_bout_debut = boutique_main()
    elif boutique == 1:
        achetable_bout_debut = boutique_capit()
    elif boutique ==2:
        achetable_bout_debut = boutique_port()
    elif boutique  == 3:
        achetable_bout_debut = boutique_jungle()
    elif boutique == 4:
        achetable_bout_debut = boutique_volcan()
    print("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*")
    print("Bonjour, cher mouto... euh client, bienvenue dans ma modeste boutique. Comment pourrais-je vous aider ?")
    print("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*")
    choix_march=int(input("1-Acheter ; 2-Vendre ; 3- Partir"))
    while ((choix_march) !=1) and ((choix_march)!=2) and ((choix_march) != 3):
        choix_march=int(input("Bon j'ai une livraison qui m'attend. Que puis-je faire pour vous ?   1- Acheter ; 2- Vendre ;3- Partir"))
    print("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*")
    if choix_march == 1:
        print("Cela tombe bien je viens de recevoir de nouveaux articles qui vont surement vous plaire !")
        print("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*")
        boutique0 = [e["nom"] for e in objets if (int(e['Bouti-achet']) == 0)]
        boutique0_indice = boutique_main()
        print(boutique0)
        choix_acheter = int(input("Que voulez vous acheter? (Entrez le numéro correspondant (en commençant par 1))"))
        indice = boutique0_indice[choix_acheter-1]
        print("Choix :", objets[indice]["nom"])
        valeur_indice = (objets[indice][('valeur')])
        print("Prix :",(objets[indice][('valeur')])," pièces ")
        choix_nom = (objets[indice]["nom"])
        choix_fait =0
        while choix_fait==0:
            achetes=int(input("Voulez vous vraiment acheter ceci ? | 1: OUI , 2: NON |   "))
            if achetes == 1:   
                if stat['argent'] >= int(valeur_indice):
                    nombre_a_acheter=(boutique0_indice[choix_acheter-1])
                    stat['argent'] = stat['argent'] - int(valeur_indice)
                    if choix_nom in inventaire:
                        inventaire[choix_nom] = inventaire[choix_nom]+1
                        boutique_debut(boutique,stat,inventaire)
                    else:
                        inventaire[choix_nom]=1
                        print("Votre inventaire :", inventaire)
                        print("Votre monnaie restante:", stat['argent'])
                        boutique_debut(boutique,stat,inventaire)
                        choix_fait=1
                else:
                    print("Vous n'avez pas assez de monnaie pour acheter ceci.")
                    boutique_debut(boutique,stat,inventaire)
                    choix_fait=1
            elif achetes == 2:
                print("Alors que faites vous ici?! Vous achetez quelque chose ou vous vous en allez, vous faites fuir les clients.")
                boutique_debut(boutique,stat,inventaire)
                choix_fait=1
    elif choix_march == 2:
        vente(stat,inventaire)
    elif choix_march == 3:
        print("Au revoir cher client !(Grmml c'était bien la peine de me déranger)'")
        print("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*")
        return inventaire,stat
    return -1

